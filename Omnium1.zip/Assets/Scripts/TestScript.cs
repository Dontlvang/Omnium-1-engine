using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript : MonoBehaviour
{
    public int[] numbers = new int[4] {1 , 2 ,3 ,4 };
    public float Speed;

    // Start is called before the first frame update
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        int number = numbers[3];
        float moveHorizontical = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        

        Vector3 movementVector = new Vector3(moveHorizontical , 0 , moveVertical);

        transform.position = transform.position + movementVector * Speed * Time.deltaTime;
    }
}
